Name: Andrew Cheng
Dot Number: .620
Email: cheng.620@osu.edu
Compile Instructions:
python3 minimax.py
python3 h_minimax.py
